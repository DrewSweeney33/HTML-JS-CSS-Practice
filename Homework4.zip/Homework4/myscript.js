function processForm(rodeotickets) 
{
    let x1 = 0;
    let x2 = 0;
    let x3 = 0;
    msg = "";
    x1cost = 0;
    x2cost = 0;
    x3cost = 0;
    console.log("here 1");

    if (rodeotickets.july5.checked) 
    {
          console.log("july 5");
          x1 = rodeotickets.july5qty.value;
          x1price = rodeotickets.july5price.value;
          console.log(x1price);
          x1cost = parseInt(x1) * parseFloat(x1price);
          msg += x1 + " tickets for July 5th for a cost of $" +
                x1cost.toFixed(2) + "<br>";

    }

    if (rodeotickets.july17.checked) 
    {
          console.log("july 17");
          x2 = rodeotickets.july17qty.value;
          x2price = rodeotickets.july17price.value;
          console.log(x2price);
          x2cost = parseInt(x2) * parseFloat(x2price);
          msg += x2 + " tickets for July 17th for a cost of $" +
                x2cost.toFixed(2) + "<br> ";
    }

    if (rodeotickets.july31.checked) 
    {
          console.log("july 31");
          x3 = rodeotickets.july5qty.value;
          x3price = rodeotickets.july31price.value;
          console.log(x3price);
          x3cost = parseInt(x3) * parseFloat(x3price);
          msg += x3 + " tickets for July 31th for a cost of $" +
                x3cost.toFixed(2) + "<br> ";
    }

    document.getElementById('output').outerHTML = "You ordered " +
      msg;

    total = parseInt(x1) + parseInt(x2) + parseInt(x3);

    console.log(total);
    // each ticket is $9.50

    amtdue = total * 9.50;
   
    return false;
}