async function getInfo()
{
    someNum = 1; 
    console.log(someNum);
    //setup the call to the web API page
    let whatUrl = "https://dummyjson.com/quotes/" + someNum;
    console.log("Got here");
    someNum++;
    response = await fetch(whatUrl);
    //have the header info but need the body
    console.log(response);
    data = await response.json();
    console.log(data);
    //msg2 = "Wind is " + data.wind + " amd it is " + data.description;
    msg1 = data.quote;
    msg2 = data.author;
    document.getElementById("ajaxbox").outerHTML = "<h3>"  + msg1 + "</h3>" + "--" + msg2 + "<br/>";
}