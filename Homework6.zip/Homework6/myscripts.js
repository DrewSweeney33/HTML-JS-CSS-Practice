$(document).ready(function()
{
    $("artcile.1").hide();
    $("artcile.2").hide();
    $("artcile.3").hide();
    $("artcile.4").hide();
    $("artcile.5").hide();
    $("artcile.6").hide();

    $("p.1").click(function()
    {
        $("article.1").toggle();
    });

    $("p.2").click(function()
    {
        $("article.2").toggle();
    });

    $("p.3").click(function()
    {
        $("article.3").toggle();
    });

    $("p.4").click(function()
    {
        $("article.4").toggle();
    });

    $("p.5").click(function()
    {
        $("article.5").toggle();
    });

    $("p.6").click(function()
    {
        $("article.6").toggle();
    });
});
